package com.example.addv;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

// @EnableAsync turns on multithreading support for @Async methods
// Without this, @Async does nothing
@Configuration
@EnableAsync
public class AsyncConfig {

// This creates a pool of background threads specifically for sending emails
// When EmailService.sendWelcomeEmail() is called, it runs in one of these
// threads — so the user's request returns instantly without waiting
    @Bean(name = "emailTaskExecutor")
    public Executor emailTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();

        executor.setCorePoolSize(2);       // 2 threads always ready
        executor.setMaxPoolSize(5);        // up to 5 threads under heavy load
        executor.setQueueCapacity(50);     // 50 emails can wait if all threads busy
        executor.setThreadNamePrefix("email-thread-");
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setAwaitTerminationSeconds(30);
        executor.initialize();

        return executor;
    }
}
