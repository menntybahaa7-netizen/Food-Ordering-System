package com.example.addv.controller;

import com.example.addv.model.FoodItem;
import com.example.addv.model.User;
import com.example.addv.repository.FoodRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class FoodController {

    private final FoodRepository foodRepository;

    public FoodController(FoodRepository foodRepository) {
        this.foodRepository = foodRepository;
    }

    @GetMapping("/view")
    public String home(Model model) {
        model.addAttribute("foods", foodRepository.findAll());
        return "home";
    }


    @GetMapping("/home")
    public String homeAlias(Model model) {
        model.addAttribute("foods", foodRepository.findAll());
        return "home";
    }

    @GetMapping("/admin/add-food")
    public String addFoodPage(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) return "redirect:/login";
        model.addAttribute("food", new FoodItem());
        return "add-food";
    }

    @PostMapping("/admin/add-food")
    public String addFood(@ModelAttribute FoodItem food, HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) return "redirect:/login";
        foodRepository.save(food);
        return "redirect:/admin/add-food?success";
    }

    @GetMapping("/admin/delete-food/{id}")
    public String deleteFood(@PathVariable Long id, HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) return "redirect:/login";
        foodRepository.deleteById(id);
        return "redirect:/view";
    }
}
