package com.example.addv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AddvApplication {

	public static void main(String[] args) {
		SpringApplication.run(AddvApplication.class, args);
	}

}
