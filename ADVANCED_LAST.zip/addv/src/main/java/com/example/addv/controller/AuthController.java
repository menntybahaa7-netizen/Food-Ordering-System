package com.example.addv.controller;

import com.example.addv.model.User;
import com.example.addv.service.CookieUtil;
import com.example.addv.service.EmailService;
import com.example.addv.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Controller
public class AuthController {

    private final UserService userService;
    private final EmailService emailService;
    private final AuthenticationManager authenticationManager;

    public AuthController(UserService userService,
                          EmailService emailService,
                          AuthenticationManager authenticationManager) {
        this.userService = userService;
        this.emailService = emailService;
        this.authenticationManager = authenticationManager;
    }

    @GetMapping("/index")
    public String home() {
        return "index";
    }

    @GetMapping("/login")
    public String viewLoginForm(@RequestParam(required = false) String error,
                                @RequestParam(required = false) String logout,
                                HttpServletRequest request,
                                Model model) {
        if (error != null) {
            model.addAttribute("error", "Invalid email or password.");
        }
        if (logout != null) {
            model.addAttribute("message", "You have been logged out.");
        }
        String lastLogin = CookieUtil.get(request, CookieUtil.LAST_LOGIN);
        if (lastLogin != null) {
            model.addAttribute("lastLogin", lastLogin.replace("_", " "));
        }
        return "login";
    }

    @GetMapping("/register")
    public String viewRegisterForm(Model model) {
        model.addAttribute("user", new User());
        return "register";
    }

    @PostMapping("/register")
    public String registerUser(@Valid @ModelAttribute("user") User user,
                               BindingResult result,
                               Model model,
                               HttpServletRequest request,
                               HttpServletResponse response,
                               HttpSession session) {

        // Show validation errors on the form
        if (result.hasErrors()) {
            return "register";
        }

        String rawPassword = user.getPassword();

        // Default role is ROLE_USER unless they selected admin
        if (user.getRole() == null || user.getRole().isBlank()) {
            user.setRole("ROLE_USER");
        }

        User savedUser = userService.createUser(user);
        if (savedUser == null) {
            model.addAttribute("error", "Email already exists.");
            return "register";
        }

        emailService.sendWelcomeEmail(savedUser);

        String now = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH:mm"));
        CookieUtil.set(response, CookieUtil.LAST_LOGIN, now, CookieUtil.THIRTY_DAYS);

        try {
            Authentication auth = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(user.getEmail(), rawPassword)
            );
            SecurityContextHolder.getContext().setAuthentication(auth);
            session.setAttribute(
                    HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY,
                    SecurityContextHolder.getContext()
            );
            session.setAttribute("user", savedUser);
        } catch (Exception e) {
            return "redirect:/login";
        }

        if ("ROLE_ADMIN".equals(savedUser.getRole())) {
            return "redirect:/admin/dashboard";
        }
        return "redirect:/view";
    }
}