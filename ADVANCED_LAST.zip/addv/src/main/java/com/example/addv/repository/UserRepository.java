package com.example.addv.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.addv.model.User;

public interface UserRepository extends JpaRepository<User,Long> {
	Optional<User> findByEmail(String email);

}
