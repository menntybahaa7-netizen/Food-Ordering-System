package com.example.addv.controller;

import com.example.addv.service.CartService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;



@Controller
@RequestMapping("/cart")
public class CartController {

    private final CartService cartService;

    public CartController(CartService cartService) {
        this.cartService = cartService;
    }


    @GetMapping
    public String viewCart(Model model) {
        model.addAttribute("cartItems",    cartService.getItems());
        model.addAttribute("grandTotal",   cartService.getGrandTotal());
        model.addAttribute("totalQty",     cartService.getTotalQuantity());
        return "cart";   //
    }

    @PostMapping("/add")
    public String addToCart(@RequestParam Long   productId,
                            @RequestParam String productName,
                            @RequestParam double price,
                            @RequestParam(defaultValue = "1") int quantity,
                            RedirectAttributes ra) {

        cartService.addItem(productId, productName, price, quantity);
        ra.addFlashAttribute("successMessage",
                "\"" + productName + "\" was added to your cart.");
        return "redirect:/cart";
    }


    @PostMapping("/remove/{productId}")
    public String removeFromCart(@PathVariable Long productId,
                                 RedirectAttributes ra) {
        cartService.removeItem(productId);
        ra.addFlashAttribute("successMessage", "Item removed from cart.");
        return "redirect:/cart";
    }
    

    @PostMapping("/clear")
    public String clearCart(RedirectAttributes ra) {
        cartService.clearCart();
        ra.addFlashAttribute("successMessage", "Cart cleared.");
        return "redirect:/cart";
    }
}