package com.example.addv.service;

import com.example.addv.model.Cart;
import com.example.addv.model.Order;
import com.example.addv.repository.OrderRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class OrderService {

    private final OrderRepository orderRepository;

    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    public Order placeOrder(String username, String userEmail, List<Cart> cartItems, double grandTotal) {
        Order order = new Order();
        order.setUsername(username);
        order.setUserEmail(userEmail);
        order.setTotalAmount(grandTotal);
        order.setStatus("PENDING");
        order.setOrderDate(LocalDateTime.now());

        StringBuilder sb = new StringBuilder();
        for (Cart item : cartItems) {
            sb.append(item.getProductName())
              .append(" x").append(item.getQuantity())
              .append(", ");
        }
        if (sb.length() > 2) sb.setLength(sb.length() - 2); // remove trailing ", "
        order.setItemsSummary(sb.toString());

        return orderRepository.save(order);
    }

    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    public List<Order> getOrdersByEmail(String email) {
        return orderRepository.findByUserEmail(email);
    }

    public void updateStatus(Long id, String status) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        order.setStatus(status);
        orderRepository.save(order);
    }
}
