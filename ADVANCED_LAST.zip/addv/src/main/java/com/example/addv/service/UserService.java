package com.example.addv.service;

import java.util.Optional;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.addv.model.User;
import com.example.addv.repository.UserRepository;

@Service
public class UserService {

    private final UserRepository repo;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository repo, PasswordEncoder passwordEncoder) {
        this.repo = repo;
        this.passwordEncoder = passwordEncoder;
    }

    public User findByEmail(String email) {
        return repo.findByEmail(email).orElse(null);
    }

    public User createUser(User user) {
        Optional<User> existing = repo.findByEmail(user.getEmail());
        if (existing.isPresent()) {
            return null; 
        }

        user.setPassword(passwordEncoder.encode(user.getPassword()));

        return repo.save(user);
    }


    public User login(String email, String password) {
        Optional<User> optUser = repo.findByEmail(email);
        if (optUser.isEmpty()) return null;

        User user = optUser.get();


        if (passwordEncoder.matches(password, user.getPassword())) {
            return user;
        }
        return null;
    }
}