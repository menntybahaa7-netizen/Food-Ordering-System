package com.example.addv.service;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class CookieUtil {

 
    public static void set(HttpServletResponse response,
                           String name,
                           String value,
                           int maxAgeSec) {
        Cookie cookie = new Cookie(name, value);
        cookie.setMaxAge(maxAgeSec);
        cookie.setPath("/");
        cookie.setHttpOnly(true); 
        response.addCookie(cookie);
    }


    public static String get(HttpServletRequest request, String name) {
        if (request.getCookies() == null) return null;

        for (Cookie cookie : request.getCookies()) {
            if (cookie.getName().equals(name)) {
                return cookie.getValue();
            }
        }
        return null;
    }


    public static void delete(HttpServletResponse response, String name) {
        Cookie cookie = new Cookie(name, "");
        cookie.setMaxAge(0);
        cookie.setPath("/");
        response.addCookie(cookie);
    }


    public static final String LAST_LOGIN  = "LAST_LOGIN";
    public static final int    THIRTY_DAYS = 30 * 24 * 60 * 60;
}