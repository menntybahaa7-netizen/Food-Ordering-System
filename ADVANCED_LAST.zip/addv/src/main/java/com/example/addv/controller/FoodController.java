package com.example.addv.controller;

import com.example.addv.model.FoodItem;
import com.example.addv.model.User;
import com.example.addv.repository.FoodRepository;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class FoodController {

    private final FoodRepository foodRepository;

    public FoodController(FoodRepository foodRepository) {
        this.foodRepository = foodRepository;
    }

    // User home page — menu
    @GetMapping("/view")
    public String home(Model model) {
        model.addAttribute("foods", foodRepository.findAll());
        return "home";
    }

    @GetMapping("/home")
    public String homeAlias(Model model) {
        model.addAttribute("foods", foodRepository.findAll());
        return "home";
    }

    // Admin only — Spring Security blocks non-admins via /admin/** rule
    @GetMapping("/admin/add-food")
    public String addFoodPage(Model model) {
        model.addAttribute("food", new FoodItem());
        return "add-food";
    }

    @PostMapping("/admin/add-food")
    public String addFood(@Valid @ModelAttribute("food") FoodItem food,
                          BindingResult result,
                          Model model) {
        if (result.hasErrors()) {
            return "add-food";
        }
        foodRepository.save(food);
        return "redirect:/admin/add-food?success";
    }

    @GetMapping("/admin/delete-food/{id}")
    public String deleteFood(@PathVariable Long id) {
        foodRepository.deleteById(id);
        return "redirect:/view";
    }
}