package com.example.addv.controller;

import com.example.addv.model.Order;
import com.example.addv.model.User;
import com.example.addv.service.CartService;
import com.example.addv.service.EmailService;
import com.example.addv.service.OrderService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class OrderController {

    private final OrderService orderService;
    private final CartService cartService;
    private final EmailService emailService;

    public OrderController(OrderService orderService,
                           CartService cartService,
                           EmailService emailService) {
        this.orderService = orderService;
        this.cartService  = cartService;
        this.emailService = emailService;
    }

    // Admin dashboard — summary page
    @GetMapping("/admin/dashboard")
    public String adminDashboard(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) return "redirect:/login";

        model.addAttribute("totalOrders",  orderService.getAllOrders().size());
        model.addAttribute("pendingOrders",
                orderService.getAllOrders().stream()
                        .filter(o -> "PENDING".equals(o.getStatus())).count());
        model.addAttribute("recentOrders",
                orderService.getAllOrders().stream()
                        .sorted((a, b) -> b.getOrderDate().compareTo(a.getOrderDate()))
                        .limit(5).toList());
        return "admin-dashboard";
    }

    // Admin — all orders
    @GetMapping("/admin/orders")
    public String adminOrders(Model model) {
        model.addAttribute("orders", orderService.getAllOrders());
        return "admin-orders";
    }

    @PostMapping("/admin/orders/update")
    public String updateStatus(@RequestParam Long id, @RequestParam String status) {
        orderService.updateStatus(id, status);
        return "redirect:/admin/orders";
    }

    // User — checkout
    @GetMapping("/checkout")
    public String checkoutPage(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) return "redirect:/login";
        if (cartService.getItems().isEmpty()) return "redirect:/cart";

        model.addAttribute("cartItems", cartService.getItems());
        model.addAttribute("grandTotal", cartService.getGrandTotal());
        model.addAttribute("user", user);
        return "checkout";
    }

    @PostMapping("/checkout")
    public String placeOrder(HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) return "redirect:/login";
        if (cartService.getItems().isEmpty()) return "redirect:/cart";

        String username = user.getFname() + " " + user.getLname();
        orderService.placeOrder(username, user.getEmail(),
                cartService.getItems(), cartService.getGrandTotal());

        emailService.sendOrderConfirmationEmail(user,
                cartService.getItems(), cartService.getGrandTotal());

        cartService.clearCart();
        return "redirect:/order-success";
    }

    @GetMapping("/order-success")
    public String orderSuccess() {
        return "order-success";
    }

    // User — my orders
    @GetMapping("/my-orders")
    public String myOrders(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) return "redirect:/login";

        List<Order> orders = orderService.getOrdersByEmail(user.getEmail());
        model.addAttribute("orders", orders);
        return "my-orders";
    }
}