package com.example.addv.service;

import com.example.addv.model.Cart;
import com.example.addv.model.User;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import java.util.List;

@Service
public class EmailService {

    private final JavaMailSender mailSender;

    @Value("${spring.mail.username}")
    private String fromEmail;

    @Value("${app.name}")
    private String appName;

    @Value("${app.base-url}")
    private String baseUrl;

    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    public void sendWelcomeEmail(User user) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            helper.setFrom(fromEmail);
            helper.setTo(user.getEmail());
            helper.setSubject("Welcome to " + appName + "!");
            helper.setText(buildWelcomeHtml(user), true);

            mailSender.send(message);
            System.out.println("[email] Welcome email sent to: " + user.getEmail());

        } catch (MessagingException e) {
            System.err.println("[email] Welcome email failed: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void sendOrderConfirmationEmail(User user, List<Cart> items, double grandTotal) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            helper.setFrom(fromEmail);
            helper.setTo(user.getEmail());
            helper.setSubject(appName + " - Your Order is Confirmed!");
            helper.setText(buildOrderHtml(user, items, grandTotal), true);

            mailSender.send(message);
            System.out.println("[email] Order confirmation sent to: " + user.getEmail());

        } catch (MessagingException e) {
            System.err.println("[email] Order email failed: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private String buildWelcomeHtml(User user) {
        return """
            <html>
            <body style="font-family:Arial,sans-serif; background:#f4f4f4; padding:20px;">
              <div style="max-width:600px; margin:auto; background:#fff;
                          border-radius:8px; padding:30px;">

                <h2 style="color:#333;">Welcome to %s, %s!</h2>

                <p style="color:#555;">Your account has been created. Here are your details:</p>

                <table style="width:100%%; border-collapse:collapse; margin:20px 0;">
                  <tr style="background:#f8f8f8;">
                    <td style="padding:10px; border:1px solid #ddd;"><b>Full Name</b></td>
                    <td style="padding:10px; border:1px solid #ddd;">%s %s</td>
                  </tr>
                  <tr>
                    <td style="padding:10px; border:1px solid #ddd;"><b>Email</b></td>
                    <td style="padding:10px; border:1px solid #ddd;">%s</td>
                  </tr>
                </table>

                <a href="%s/view"
                   style="display:inline-block; background:#007bff; color:#fff;
                          padding:12px 24px; text-decoration:none; border-radius:5px;">
                  Start Ordering
                </a>

                <p style="color:#999; font-size:12px; margin-top:20px;">
                  If you did not create this account, ignore this email.
                </p>
              </div>
            </body>
            </html>
            """.formatted(
                appName, user.getFname(),
                user.getFname(), user.getLname(),
                user.getEmail(),
                baseUrl
        );
    }

    private String buildOrderHtml(User user, List<Cart> items, double grandTotal) {
        StringBuilder rows = new StringBuilder();
        for (Cart item : items) {
            rows.append("""
                <tr>
                  <td style="padding:10px; border:1px solid #ddd;">%s</td>
                  <td style="padding:10px; border:1px solid #ddd; text-align:center;">%d</td>
                  <td style="padding:10px; border:1px solid #ddd; text-align:right;">$%.2f</td>
                  <td style="padding:10px; border:1px solid #ddd; text-align:right;">$%.2f</td>
                </tr>
                """.formatted(
                    item.getProductName(),
                    item.getQuantity(),
                    item.getPrice(),
                    item.getSubtotal()
            ));
        }

        return """
            <html>
            <body style="font-family:Arial,sans-serif; background:#f4f4f4; padding:20px;">
              <div style="max-width:600px; margin:auto; background:#fff;
                          border-radius:8px; padding:30px;">

                <h2 style="color:#333;">Order Confirmed!</h2>
                <p style="color:#555;">Hi %s, your order has been placed.</p>

                <table style="width:100%%; border-collapse:collapse; margin:20px 0;">
                  <thead>
                    <tr style="background:#343a40; color:#fff;">
                      <th style="padding:10px; text-align:left;">Item</th>
                      <th style="padding:10px;">Qty</th>
                      <th style="padding:10px;">Unit Price</th>
                      <th style="padding:10px;">Subtotal</th>
                    </tr>
                  </thead>
                  <tbody>%s</tbody>
                  <tfoot>
                    <tr style="background:#f8f8f8; font-weight:bold;">
                      <td colspan="3" style="padding:10px; border:1px solid #ddd;">Grand Total</td>
                      <td style="padding:10px; border:1px solid #ddd; text-align:right;">$%.2f</td>
                    </tr>
                  </tfoot>
                </table>

                <a href="%s/my-orders"
                   style="display:inline-block; background:#28a745; color:#fff;
                          padding:12px 24px; text-decoration:none; border-radius:5px;">
                  View My Orders
                </a>

              </div>
            </body>
            </html>
            """.formatted(
                user.getFname(),
                rows.toString(),
                grandTotal,
                baseUrl
        );
    }
}