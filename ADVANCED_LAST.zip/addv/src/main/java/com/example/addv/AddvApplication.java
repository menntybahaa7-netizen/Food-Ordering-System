package com.example.addv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class AddvApplication {

	public static void main(String[] args) {
		SpringApplication.run(AddvApplication.class, args);
	}

}