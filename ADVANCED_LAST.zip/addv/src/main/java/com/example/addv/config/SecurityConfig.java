package com.example.addv.config;

import com.example.addv.model.User;
import com.example.addv.service.CookieUtil;
import com.example.addv.service.CustomUserDetailsService;
import com.example.addv.service.UserService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final CustomUserDetailsService userDetailsService;
    private final PasswordEncoder passwordEncoder;
    private final UserService userService;

    public SecurityConfig(CustomUserDetailsService userDetailsService,
                          PasswordEncoder passwordEncoder,
                          UserService userService) {
        this.userDetailsService = userDetailsService;
        this.passwordEncoder    = passwordEncoder;
        this.userService        = userService;
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(userDetailsService);
        provider.setPasswordEncoder(passwordEncoder);
        return provider;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            // Disable CSRF so original HTML forms work without hidden token
            .csrf(csrf -> csrf.disable())

            .authorizeHttpRequests(auth -> auth
            	    .requestMatchers("/", "/login", "/register", "/index",
            	                     "/css/**", "/js/**", "/images/**", "/error").permitAll()
            	    .requestMatchers("/admin/**").hasRole("ADMIN")
            	    .anyRequest().authenticated()
            	)
            .formLogin(form -> form
                .loginPage("/login")
                .usernameParameter("email")
                .passwordParameter("password")
                // After login: load user into session, set cookie, redirect by role
                .successHandler((request, response, authentication) -> {
                    String email = authentication.getName();
                    User user = userService.findByEmail(email);
                    request.getSession().setAttribute("user", user);

                    String now = LocalDateTime.now()
                            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH:mm"));
                    CookieUtil.set(response, CookieUtil.LAST_LOGIN, now, CookieUtil.THIRTY_DAYS);

                    // Redirect admin to dashboard, regular user to menu
                    if ("ROLE_ADMIN".equals(user.getRole())) {
                        response.sendRedirect("/admin/dashboard");
                    } else {
                        response.sendRedirect("/view");
                    }
                })
                .failureUrl("/login?error=true")
                .permitAll()
            )
            .rememberMe(remember -> remember
                .userDetailsService(userDetailsService)
                .key("addv-secret-key-change-this")
                .tokenValiditySeconds(30 * 24 * 60 * 60)
                .rememberMeParameter("remember-me")
                .rememberMeCookieName("ADDV_REMEMBER")
            )
            .logout(logout -> logout
                // Allow GET logout so <a href="/logout"> works
                .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                .logoutSuccessUrl("/login?logout=true")
                .deleteCookies("JSESSIONID", "ADDV_REMEMBER", "LAST_LOGIN")
                .invalidateHttpSession(true)
                .clearAuthentication(true)
                .permitAll()
            )
            .authenticationProvider(authenticationProvider());

        return http.build();
    }
}