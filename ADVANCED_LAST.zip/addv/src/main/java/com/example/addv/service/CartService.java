package com.example.addv.service;

import com.example.addv.model.Cart;
import org.springframework.stereotype.Service;
import org.springframework.web.context.annotation.SessionScope;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@SessionScope
public class CartService {

    private final List<Cart> items = new ArrayList<>();

   
    public void addItem(Long productId, String productName, double price, int quantity) {
        Optional<Cart> existing = findById(productId);

        if (existing.isPresent()) {
            existing.get().setQuantity(existing.get().getQuantity() + quantity);
        } else {
            items.add(new Cart(productId, productName, price, quantity));
        }
    }

 

    public void removeItem(Long productId) {
        items.removeIf(item -> item.getProductId().equals(productId));
    }


    public void clearCart() {
        items.clear();
    }


    public List<Cart> getItems() {
        return items;
    }

    public int getTotalQuantity() {
        return items.stream().mapToInt(Cart::getQuantity).sum();
    }

    public double getGrandTotal() {
        return items.stream().mapToDouble(Cart::getSubtotal).sum();
    }


    private Optional<Cart> findById(Long productId) {
        return items.stream()
                    .filter(i -> i.getProductId().equals(productId))
                    .findFirst();
    }
}