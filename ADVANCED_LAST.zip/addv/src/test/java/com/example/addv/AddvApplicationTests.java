package com.example.addv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AddvApplicationTests {

	@Test
	void contextLoads() {
	}

}
